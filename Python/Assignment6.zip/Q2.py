
""""
2. Generate fibnoacci series for 1 to 20

"""


a1=0
a2=1
a3=1
while(a3<=20):
    print(a3)
    a1=a2
    a2=a3
    a3=a1+a2
